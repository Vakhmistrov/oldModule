var iframe_count = 0;

var QueryParameters = (function () {
    var result = {};
    if (window.location.search) {
        var params = window.location.search.slice(1).split("&");
        for (var i = 0; i < params.length; i++) {
            var tmp = params[i].split("=");
            result[tmp[0]] = unescape(tmp[1]);
        }
    }
    return result;
}());

function DynamicIFrames_Count() {
    var IFrames_Count = 0;
    var dyn_iframes;
    dyn_iframes = window.parent.document.getElementsByTagName('iframe');
    for (i = 0; i < dyn_iframes.length; i++) if (dyn_iframes[i].getAttribute('name') == 'Dynamic_IFrame') IFrames_Count++;
    return IFrames_Count;
}


function ShowModalDiv(strUrl, iHeight, iWidth, valueForPostBack, header) {
    /* ��������� �������� ��. � ����� /JS/dynamic_iframes_instruction.docx */

    iHeight = iHeight.toString().replace("px", "");
    iWidth = iWidth.toString().replace("px", "");

    var IFrameDiv_Number = DynamicIFrames_Count();

    var lm_Width;
    var lm_Height;
    var lm_Width_inner;
    var lm_Height_inner;
    var lm_Width_oframe;
    var lm_Height_iframe;

    var IFrameDiv_bkg = document.createElement('div');
    IFrameDiv_bkg.id = 'IFrameDiv_' + IFrameDiv_Number + '_bkg';
    IFrameDiv_bkg.name = 'IFrameDiv_bkg';

    IFrameDiv_bkg.className = 'IFrameDiv_bkg'; // � ���� ���������� ���� ��������� �������� � �����!! :-�
    IFrameDiv_bkg.style.position = 'absolute';
    IFrameDiv_bkg.style.top = '0';
    IFrameDiv_bkg.style.left = '0';
    IFrameDiv_bkg.style.width = '100%';
    IFrameDiv_bkg.style.height = '100%';
    IFrameDiv_bkg.style.backgroundColor = 'black';
    IFrameDiv_bkg.style.opacity = '0.45';

    IFrameDiv_bkg.style.zIndex = 900 + IFrameDiv_Number * 2;

    var IFrameDiv = document.createElement('div');
    IFrameDiv.id = 'IFrameDiv_' + IFrameDiv_Number;
    IFrameDiv.name = 'IFrameDiv';

    IFrameDiv.className = 'IFrameDiv';

    // ML: Adjusting parameters depending on browser size
    if ((parseInt(iHeight) + 40) > window.parent.document.documentElement.clientHeight) {
        IFrameDiv.style.top = '20px';
        IFrameDiv.style.left = (window.parent.document.body.offsetWidth - iWidth - 10) / 2 - 17 / 2 + 'px'; //ML: border:10px; 17 - scrollbar
        IFrameDiv.style.width = (parseInt(iWidth, 10) + 20 + 17) + "px"; // ML: 20 + 17 = borders + scrollbar
        IFrameDiv.style.height = (window.parent.document.documentElement.clientHeight - 40) + "px";

        lm_Width = (parseInt(iWidth, 10) + 20 + 17);
        lm_Height = (window.parent.document.documentElement.clientHeight - 40);
    }
    else {
        IFrameDiv.style.top = (window.parent.document.documentElement.clientHeight - iHeight) / 2 + 'px';
        IFrameDiv.style.left = (window.parent.document.body.offsetWidth - iWidth - 10) / 2 + 'px'; //ML: border:10px
        IFrameDiv.style.width = (parseInt(iWidth, 10) + 20) + "px";
        IFrameDiv.style.height = (parseInt(iHeight) + 31) + "px"; // !!!!!!!!!!! 2 change   

        lm_Width = (parseInt(iWidth, 10) + 20);
        lm_Height = (parseInt(iHeight) + 31);
    }
    IFrameDiv.style.zIndex = 900 + IFrameDiv_Number * 2 + 1;

    if (IFrameDiv_Number > 0) {
        window.parent.$('#IFrameDiv_' + (IFrameDiv_Number - 1) + '_minimize').css({ display: 'none' });
        window.parent.document.getElementById('IFrameDiv_' + (IFrameDiv_Number - 1) + '_closer').style.display = 'none';
        window.parent.document.getElementById('IFrameDiv_' + (IFrameDiv_Number - 1) + '_bkg').style.display = 'none';
    }
    window.parent.document.body.appendChild(IFrameDiv);

    var IFrameDiv_inner = document.createElement('div');

    IFrameDiv_inner.id = 'IFrameDiv_' + IFrameDiv_Number + '_inner';
    IFrameDiv_inner.className = 'IFrameDiv_inner';

    if ((parseInt(iHeight) + 30) > window.parent.document.documentElement.clientHeight) {
        IFrameDiv_inner.style.width = (parseInt(iWidth, 10) + 17) + "px";
        IFrameDiv_inner.style.height = (window.parent.document.documentElement.clientHeight - 72) + "px"; // !!!!!!!!!!! 2 change
        IFrameDiv_inner.style.overflowY = "auto";

        lm_Width_inner = (parseInt(iWidth, 10) + 17);
        lm_Height_inner = (window.parent.document.documentElement.clientHeight - 72);
    }
    else {
        IFrameDiv_inner.style.width = iWidth + "px";
        IFrameDiv_inner.style.height = iHeight + "px"; // !!!!!!!!!!! 2 change

        lm_Width_inner = iWidth;
        lm_Height_inner = iHeight;
    }
    IFrameDiv.appendChild(IFrameDiv_inner);

    if (typeof header !== "undefined") {
        var IFrameDiv_header = document.createElement('div');
        IFrameDiv_header.id = 'IFrameDiv_' + IFrameDiv_Number + '_header';
        IFrameDiv_header.className = 'IFrameDiv_header';
        IFrameDiv_header.style.width = iWidth + "px"; // 100 - is the width of two buttons (Minimize and Close), also see 'padding-right:100px' and 'padding-left:100px' in CSS-class IFrameDiv_header
        IFrameDiv_header.innerHTML = "<div style='width:" + (iWidth - 200) + "px;' class='IFrameDiv_header_label'>" + header + '</div>';
        IFrameDiv_inner.appendChild(IFrameDiv_header);
    }

    var IFrameDiv_inner_PleaseWait = document.createElement('div');
    IFrameDiv_inner_PleaseWait.className = 'IFrameDiv_inner_PleaseWait';
    IFrameDiv_inner_PleaseWait.innerHTML = 'Please wait...';

    var IFrameDiv_inner_IFrame = document.createElement('div');
    IFrameDiv_inner_IFrame.id = 'IFrameDiv_' + IFrameDiv_Number + '_inner_IFrame';
    IFrameDiv_inner_PleaseWait.id = 'IFrameDiv_' + IFrameDiv_Number + '_inner_PleaseWait';
    IFrameDiv_inner_IFrame.className = 'IFrameDiv_inner_IFrame';

    IFrameDiv_inner.appendChild(IFrameDiv_inner_PleaseWait);
    IFrameDiv_inner.appendChild(IFrameDiv_inner_IFrame);

    var _iframe = document.createElement('iframe');
    var Query = '';
    if (QueryParameters.query) Query = QueryParameters.query;

    if ((Query != '') && (strUrl.indexOf("query") == -1)) {
        if (strUrl.indexOf("?", 0) != -1) {
            strUrl = strUrl + '&query=' + Query + '&referer=' + window.location.pathname;
        }
        else {
            strUrl = strUrl + '?query=' + Query + '&referer=' + window.location.pathname;
        }
    }
    if (strUrl.indexOf("?", 0) != -1) {
        strUrl = strUrl + "&iframe_number=" + IFrameDiv_Number;
    }
    else { // ������������, �������� ��� ?query ������ ��������� � Critical error � ����� (�� ������ 2013), ��� ��� ���� if - ����� ��� ������
        strUrl = strUrl + "?iframe_number=" + IFrameDiv_Number;
    }
    var isHttps = false;
    if (strUrl.indexOf("https:") != -1) {
        isHttps = true;

    }

    _iframe.src = strUrl;
    _iframe.style.width = iWidth + "px";
    _iframe.style.height = iHeight + "px";
    _iframe.id = IFrameDiv.id + "_iframe";
    _iframe.setAttribute("name", "Dynamic_IFrame");
    _iframe.setAttribute("frameborder", "0");
    _iframe.setAttribute("onload", "pageUpdater_Create('" + IFrameDiv_Number + "', '" + valueForPostBack + "',''," + isHttps + "); SetBackground('" + IFrameDiv_inner_IFrame.id + "'); FocusOnElement('" + _iframe.id + "');");
    IFrameDiv_inner_IFrame.appendChild(_iframe);
    iframe_count++;

    lm_Width_iframe = iWidth;
    lm_Height_iframe = iHeight;

    var closeButton = document.createElement('div');
    closeButton.innerHTML = "&nbsp;";

    closeButton.className = 'iframeCloseButton';

    closeButton.setAttribute("name", "IFrameDiv_closer");
    closeButton.id = IFrameDiv.id + "_closer";
    closeButton.setAttribute("returnValue", "_default_");
    IFrameDiv.appendChild(closeButton);

    if (IFrameDiv_Number > 0) {
        closeButton.setAttribute("onclick", "close_iFrame('" + _iframe.id + "'); window.parent.document.getElementById('IFrameDiv_" + (IFrameDiv_Number - 1) + "_iframe').contentDocument.getElementById('moduleCountry').click();");
    }
    else {
        closeButton.setAttribute("onclick", "close_iFrame('" + _iframe.id + "'); window.parent.document.getElementById('moduleCountry').click();");
    }

    $(window.parent.document.body).append(IFrameDiv_bkg);
    $(IFrameDiv).append(closeButton);

    // LM minimizing creation for the first level DIV#0 and #higher
    var minimizeButton = document.createElement('div');
    minimizeButton.innerHTML = "&nbsp;";

    minimizeButton.className = 'iframeMinimizeButton';
    minimizeButton.setAttribute("name", "IFrameDiv_closer");
    minimizeButton.id = IFrameDiv.id + "_minimize";
    minimizeButton.setAttribute("returnValue", "_default_");
    minimizeButton.setAttribute("onclick", "MinimizeDiv(" + lm_Width + ", " + lm_Height + ", " + lm_Width_inner + ", " + lm_Height_inner +
        ", " + lm_Width_iframe + ", " + lm_Height_iframe +
        ", " + IFrameDiv.id + ", " + IFrameDiv_inner.id + ", " + IFrameDiv_bkg.id + ", " + _iframe.id + ", " + minimizeButton.id +
        ", " + IFrameDiv_inner_IFrame.id + ", " + IFrameDiv_inner_PleaseWait.id +
        "); return false;");
    $(IFrameDiv).append(minimizeButton);

    window.parent.$(IFrameDiv).draggable({
        containment: window.parent.$(IFrameDiv_bkg),
        cursor: "text",
        start: function () {
            window.parent.$(IFrameDiv_inner).each(function (index, element) {
                var d = window.parent.$('<div id="fakeDiv_' + IFrameDiv_Number + '" class="iframeCover" style="z-index:990;position:absolute;width:100%;top:0px;left:0px;height:' + window.parent.$(element).height() + 'px"></div>');
                window.parent.$(element).append(d);
            });
        },
        stop: function () {
            window.parent.$('.iframeCover').remove();
        }
    });
}

function pageUpdater_Create(IFrameDiv_Num, valueForPostBack, oldFrameID, isHttps) {
    /* ��������� �������� ��. � ����� /JS/dynamic_iframes_instruction.docx */
    var _iframe_id = '';
    var pageUpdater = document.createElement('a');
    pageUpdater.setAttribute("name", "pageUpdater");
    pageUpdater.id = "pageUpdater";
    pageUpdater.setAttribute("returnValue", "_default_");

    if (IFrameDiv_Num == 0) {
        _iframe_id = 'IFrameDiv_' + IFrameDiv_Num + '_iframe';
        if (document.getElementById('pageUpdater') != null) {
            document.body.removeChild(document.getElementById('pageUpdater'));
        }
        document.body.appendChild(pageUpdater);
    }
    else if (IFrameDiv_Num > 0) {
        _iframe_id = 'IFrameDiv_' + (IFrameDiv_Num - 1) + '_iframe';
        if (isHttps) {
            var pageUpdaterEvent = new PageUpdater_Event(IFrameDiv_Num, valueForPostBack, oldFrameID, isHttps, _iframe_id);
            document.getElementById(_iframe_id).contentWindow.postMessage(JSON.stringify(pageUpdaterEvent), "*");
        } else {
            if (document.getElementById(_iframe_id).contentDocument.getElementById('pageUpdater') != null) {
                document.getElementById(_iframe_id).contentDocument.body.removeChild(document.getElementById(_iframe_id).contentDocument.getElementById('pageUpdater'));
            }
            document.getElementById(_iframe_id).contentDocument.body.appendChild(pageUpdater);
        }
    }

    pageUpdater.setAttribute("onclick", "updater_onclick('parent', '" + valueForPostBack + "');");

    if ($('#' + _iframe_id).contents().find('html').html().indexOf('Login.aspx') !== -1)
        window.location.href = 'RedirectToStart.aspx';
}

function close_iFrame(_iframe_id) {
    /* ��������� �������� ��. � ����� /JS/dynamic_iframes_instruction.docx */
    var IFrameMaxNumber = DynamicIFrames_Count() - 1;

    document.body.removeChild(document.getElementById(_iframe_id.replace('_iframe', '_bkg')));
    document.body.removeChild(document.getElementById(_iframe_id.replace('_iframe', '')));
    if (IFrameMaxNumber > 0) {
        document.getElementById('IFrameDiv_' + (IFrameMaxNumber - 1) + '_closer').style.display = '';
        try {//RAV error in modal window
            window.parent.document.getElementById('IFrameDiv_' + (IFrameMaxNumber - 1) + '_bkg').style.display = '';
        }
        catch (Error) { }
        collapsed = "false";
        $('#IFrameDiv_' + (IFrameMaxNumber - 1) + '_minimize').css({ display: '' }); // LM 01-10-2013
    }
}

function updater_onclick(_iframe_id, valueForPostBack) {
    /* ��������� �������� ��. � ����� /JS/dynamic_iframes_instruction.docx */
    var Updater;
    var RC;
    if (_iframe_id == 'parent')
        Updater = document.getElementById('pageUpdater').attributes.getNamedItem('returnValue');
    else
        Updater = window.parent.document.getElementById(_iframe_id).contentDocument.getElementById('pageUpdater').attributes.getNamedItem('returnValue');
    RC = Updater.value;

    if (RC == '') {
        return;
    }
    if (RC == "_refresh_" || valueForPostBack == "_refresh_") {
        if (document.getElementById('FilterPanel_btn_Refresh')) document.getElementById('FilterPanel_btn_Refresh').click();
        else __doPostBack('PostBackFromIFrame', '');
        return;
    }
    if (valueForPostBack != '' && RC.indexOf(valueForPostBack) != -1) {
        __doPostBack('PostBackFromIFrame', RC);
    }
}


function CloseModalDiv_NoRefresh(isPostMessage) {
    /* ��������� �������� ��. � ����� /JS/dynamic_iframes_instruction.docx */
    CloseModalDiv_RefreshWithResponse('', isPostMessage);
}

function CloseModalDiv_Refresh() {
    /* ��������� �������� ��. � ����� /JS/dynamic_iframes_instruction.docx */
    CloseModalDiv_RefreshWithResponse('_refresh_', false);
}

function CloseModalDiv_RefreshWithResponse(returnValue, isPostMessage) {
    /* ��������� �������� ��. � ����� /JS/dynamic_iframes_instruction.docx */
    var IFrameMaxNumber = DynamicIFrames_Count() - 1;
    if (IFrameMaxNumber > 0) {
        window.parent.document.getElementById('IFrameDiv_' + (IFrameMaxNumber - 1) + '_iframe').contentDocument.getElementById('pageUpdater').setAttribute('returnValue', returnValue);
    }
    else {
        window.parent.document.getElementById('pageUpdater').setAttribute('returnValue', returnValue);
    }

    window.parent.document.getElementById('IFrameDiv_' + IFrameMaxNumber + '_closer').click();
}

function FocusOnElement(iframe_id) {
    var elems = document.getElementById(iframe_id).contentDocument.body.getElementsByClassName('UIEditTextBox');
    if (elems.length > 0) {
        for (var i = 0; i < elems.length; i++) {
            if (elems[i].offsetHeight != 0) {
                elems[i].focus();
                break;
            }
        }
    }
}

function SetBackground(e_id) {
    var e = document.getElementById(e_id);
    if (e != null) //AR 11-DEC-2013
        e.style.backgroundColor = 'white';
}

var collapsed = "false";
var x;
var y;

function MinimizeDiv(iWidth, iHeight, iWidth_inner, iHeight_inner, iWidth_iframe, iHeight_iframe,
                     iFrameDiv_N, iFrameDiv_N_inner, iFrameDiv_N_bkg, iFrameDiv_N_iframe, iFrameDiv_N_minmaxze, IFrameDiv_N_inner_IFrame,
                     IFrameDiv_N_inner_PleaseWait) {

    if (collapsed == "false") {
        x = window.parent.$(iFrameDiv_N).offset().left;
        y = window.parent.$(iFrameDiv_N).offset().top;
        window.parent.$(iFrameDiv_N).animate({ left: $(window).width() - 180, top: $(window).height() - 22, height: "25px", width: "180px" }, 300);
        window.parent.$(iFrameDiv_N_inner).animate({ left: $(window).width() - 180, top: $(window).height() - 22, height: "0px", width: "160px" }, 300);
        window.parent.$(iFrameDiv_N_bkg).animate({ opacity: "0.15" }, 300);
        window.parent.$(IFrameDiv_N_inner_IFrame).hide();
        window.parent.$(IFrameDiv_N_inner_PleaseWait).hide();
        window.parent.$(iFrameDiv_N_inner).hide();
        window.parent.$(iFrameDiv_N_minmaxze).attr('class', 'iframeMaximizeButton');
        collapsed = "true";
    }
    else {
        window.parent.$(iFrameDiv_N_bkg).animate({ opacity: "0.45" }, 300);
        window.parent.$(iFrameDiv_N).animate({ height: iHeight, width: iWidth, left: x, top: y }, 300);
        window.parent.$(iFrameDiv_N_inner).animate({ height: iHeight_inner, width: iWidth_inner, left: 7, top: 20 }, 200);
        window.parent.$(iFrameDiv_N_minmaxze).attr('class', 'iframeMinimizeButton');
        window.parent.$(IFrameDiv_N_inner_PleaseWait).show();
        window.parent.$(IFrameDiv_N_inner_IFrame).show();
        window.parent.$(iFrameDiv_N_inner).show();
        collapsed = "false";
    }
}

function PageUpdater_Event(IFrameDiv_Num, valueForPostBack, oldFrameID, isHttps, _iframe_id) {
    this.IFrameDiv_Num = IFrameDiv_Num;
    this.valueForPostBack = valueForPostBack;
    this.oldFrameID = oldFrameID;
    this.isHttps = isHttps;
    this._iframe_id = _iframe_id;
}


//--start block-- 10.06.2016  AZ  close modal div by click left mouse button on background 
$(document).bind('mouseup', function (e) {
    if (e.which == 1) {
        var targetID = e.target.id.split('_'),
            IFrameToRemove = "IFrameDiv_" + targetID[1] + "_iframe",
            IFrameTarget = "IFrameDiv_" + targetID[1] + "_bkg";
        if (targetID[1] != undefined && e.target.id == IFrameTarget)
            close_iFrame(IFrameToRemove);
    }
});
//--end block--

function ShowModalInfo_Site(site_id) {
    ShowModalDiv("_popup_site.html", "550", "750", "");
}
function ShowModalInfo_Account(accountID) {
    ShowModalDiv("/PPT/Modules/sponsor_window.aspx?project_id=" + project_id + "&accountID=" + accountID + "&isFrameMode=1", 400, 700);
}
function ShowModalInfo_Sponsor(sponsorID) {
    ShowModalDiv("/PPT/Modules/sponsor.aspx?project_id=" + project_id + "&isFrameMode=1", 800, 1200);
}
function ShowModalInfo_Employee(employeeID) {
    ShowModalDiv("/CORE/MODAL/user_info.aspx?id=" + employeeID, "500", "740", "");
}

function ShowModalInfo_Visit(visit_id) {
    ShowModalDiv("_popup_reasons.html", "550", "750", "");
}
