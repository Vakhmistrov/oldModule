        var project_id, project_name, CenterBlock_height, CenterBlock_width, CenterBlock_top;
        var currentModule;
        var updateInProgress = false;
		
		$(document).ready(function(){
			var Version = 1;
			$('#top_Header').append('<div class="Version">Version #'+ Version +'</div>');
		});
		
		$('#top_Header').css('background','red');

        $(function () {
            project_id = $('#hfld_PROJECT_CODE').val();
            project_name = $('#hfld_PROJECT_NAME').val();

            //$('#PPT_CenterBlock').css({ height: $(window).height() - 70 });
            CenterBlock_height = $('#PPT_CenterBlock').outerHeight();

            var CenterBlockInner_Height = CenterBlock_height - $('#MenuBar_Main').outerHeight(true) - $('#moduleTitle').outerHeight(true) - 10; // 10 - bottom-margin from #PPT_CenterBlock's bottom
            //$('#CenterBlockInner').css({ height: CenterBlockInner_Height });
            CenterBlockInner_height = $('#CenterBlockInner').outerHeight(true);

            CenterBlock_width = $('#PPT_CenterBlock').outerWidth();
            CenterBlock_top = 120;

            var MinWidth = 800;
            var MaxWidth = 1530;
            var CenterBlock_Width = ($(window).width() > MaxWidth ? MaxWidth : $(window).width()) - 40;
            if (CenterBlock_Width < MinWidth) CenterBlock_Width = MinWidth;

            $('#div_Title').html($('#hfld_PROJECT_NAME').val());
            $('#div_ProjectStatus').html($('#hfld_PROJECT_STATUS').val());
            //$('#top_Header').css({ width: CenterBlock_Width });
            //$('#PPT_CenterBlock').css({ width: CenterBlock_Width });
            //$('#CenterBlockInner').css({ width: CenterBlock_Width - 20 });

            var stopPropagationScript = function (event) { event.preventDefault(); event.stopPropagation(); };
            $('.MenuBar_Additional, .MenuItem_Add').click(stopPropagationScript);

            $('.MenuItem').each(function () {
                var MenuBar_Add = $(this).find('.MenuBar_Additional');
                var f = $(this).find('.MenuItem_Add:first-child');
                if (f.length > 0 && $(this).attr('itemName') != 'DropDown') {
                    var onclick_script = f.attr("onclick").replace('this', '$(this).find(".MenuItem_Add:first-child")');
                    $(this).attr('onclick', onclick_script);
                }
                if ($(this).attr('itemName') == 'DropDown') {
                    var onclick_script = function () { };
                    $(this).attr('onclick', onclick_script);
                }
            });

            //MenuAddItemClick($('#item_CurrentStatus'), { moduleName: "current_status" });
            
        });

        function LoadPage_Ajax(url, isBreadCrumb_UpperLevel, parms) {
			/*
            if (parms && parms.moduleName) {
                currentModule = parms.moduleName;
            }
            if (parms && !parms.moduleName && parms.action == 'ChangeCountry' && currentModule) {
                url = currentModule;
            }

            $('#div_Fog').css({
                height: $('#PPT_CenterBlock').outerHeight(),
                width: $('#PPT_CenterBlock').outerWidth()
            }).appendTo('#PPT_CenterBlock');

            $('#div_Fog').fadeIn('fast');
            if (!$('#img_Preloader').is(':visible'))
                $('#img_Preloader').fadeIn('fast');

            if (url.indexOf('.aspx') == -1)
                url = 'modules/' + url + '.aspx'

            var breadCrumb_Item = null;

            if (isBreadCrumb_UpperLevel) {
                $('#moduleTitle').find('[breadCrumb_Country]').remove();
                $('#moduleTitle').find('[breadCrumb_Site]').remove();
                $('#moduleTitle').find('[breadCrumb_Delimeter]').remove();
            }

            if (parms && parms.mode && parms.objectTitle && (parms.mode == 'grid_region' || parms.mode == 'grid_site')) {
                breadCrumb_Item = $('<div>').on('click', function () { ($('.icon_table').hasClass('active') || parms.mode == 'grid_region') ? parms.action = '' : parms.action == 'ChangeCountry'; LoadPage_Ajax(url, false, parms) }).html(parms.objectTitle);

                var breadCrumb_Name;
                if (parms.mode == 'grid_region') {
                    $('#div_btnBack').attr('onclick', "$('#moduleTitle').find('[breadCrumb_Module]').click();");
                    breadCrumb_Name = 'breadCrumb_Country';
                    if ($('#moduleTitle').find('[breadCrumb_Site]').length > 0) {
                        $('#moduleTitle').find('[breadCrumb_Site]').remove();
                        $('#moduleTitle').find('[breadCrumb_Delimeter]').last().remove();
                    }
                }
                if (parms.mode == 'grid_site') {
                    $('#div_btnBack').attr('onclick', "$('#moduleTitle').find('[breadCrumb_Country]').click();");
                    breadCrumb_Name = 'breadCrumb_Site';
                }

                var breadCrumb_Delimeter_0 = $('<div>').addClass('breadCrumb_Delimeter_0');
                var breadCrumb_Delimeter_1 = $('<div>').addClass('breadCrumb_Delimeter_1');
                var breadCrumb_Delimeter_2 = $('<div>').addClass('breadCrumb_Delimeter_2');
                breadCrumb_Item.append(breadCrumb_Delimeter_1).append(breadCrumb_Delimeter_2).append(breadCrumb_Delimeter_0);

                breadCrumb_Item.attr(breadCrumb_Name, parms.object_id);
                $('#moduleTitle').find('[' + breadCrumb_Name + ']').remove();
                if ($('#moduleTitle').find('[' + breadCrumb_Name + ']').length == 0)
                    $('#moduleTitle').append(breadCrumb_Item);
            }
			*/
        };
		
		function showPopup(item,message){
			
		message = 'Available in online version'; // hardcode Message
		if ($(item).find('.popup').length > 0 && $(item).find('.popup').css('display') != 'none') {
		$('.popup').remove();
		$(item).find('.popup').remove();
		}
		else {
		$('.popup').remove();
		$(item).css('position','relative').append('<div class="popup">'+message+'</div>').find('.popup').delay(2000).fadeOut(1000);
		}
		}

        function MenuAddItemClick(e, parms) {
            if (updateInProgress) return;
            
            if (window.event) {
                window.event.preventDefault();
                window.event.stopPropagation();
            }

            $('.MenuBar_Additional').removeClass('Visible');
            $('.MenuItem_Add').removeClass('item_Active');
            $('.MenuItem').removeClass('item_Active');

            $(e).closest('div[itemName]').removeClass('Hovered').addClass('item_Active');
            $(e).closest('.MenuBar_Additional').addClass('Visible');
            $(e).addClass('item_Active');

            var CenterBlockInner_marginTop;
            if ($(e).attr('moduleTitle')) CenterBlockInner_marginTop = 0;
            else CenterBlockInner_marginTop = $(e).closest('.MenuBar_Additional').outerHeight(true);
			
			var link = parms.moduleName;
			window.location.href = link + ".html";
        };

        function moduleTitle_Init(e, f) {
            $('#moduleTitle').html('');
            if ($(e).attr('moduleTitle') && $('#moduleTitle').find('[breadCrumb_Module]').length == 0) {
                var breadCrumb_Module = $('<div>').attr('breadCrumb_Module', '').on('click', f).html($(e).attr('moduleTitle'));
                var breadCrumb_Delimeter_0 = $('<div>').addClass('breadCrumb_Delimeter_0');
                breadCrumb_Module.append(breadCrumb_Delimeter_0);
                $('#moduleTitle').append(breadCrumb_Module).fadeIn();
            }
            else
                $('#moduleTitle').fadeOut();
        };

        function Show_NoDataWindow() {
            var isButtonBackVisible = $('#moduleTitle').find('[breadCrumb_Country]').length > 0 || $('#moduleTitle').find('[breadCrumb_Site]').length > 0;
            var div_NoData_Clone = $('#div_NoData').clone();
            if (isButtonBackVisible)
                div_NoData_Clone.find('#div_btnBack').css('display', '');
            else
                div_NoData_Clone.find('#div_btnBack').css('display', 'none');

            $('#CenterBlockInner').html('').append(div_NoData_Clone).fadeIn();
            $('#img_Preloader').fadeOut('fast', function () { $('#div_NoData').fadeIn('fast'); });
        };

        function MenuItemClick(e, itemName) {
            if (updateInProgress) return;

            $('.MenuBar_Additional').removeClass('Visible');
            $('.MenuItem_Add').removeClass('item_Active');
            $('.MenuItem').removeClass('item_Active');

            $('#item_' + itemName).addClass('item_Active');

            $('.CenterBlockInner').fadeOut('fast', function () {
                $(this).css({
                    marginTop: 0
                })
                $('#img_Preloader').fadeIn('fast');

                var url = 'modules/';
                var changeContent = false;

                if (changeContent) {
                    LoadPage_Ajax(url);
                    moduleTitle_Init(e, function () { LoadPage_Ajax(url) });
                }
                else {
                    Show_NoDataWindow();
                }
            });
        }

        function isRedirect(html) { return true; } // Overloaded if !CIS.PPT.CheckIsPrima (see ph_Portal00)

        function onAjaxSuccess(html) {
            updateInProgress = false;

            if (!isRedirect(html)) return;

            var loginPage = $(html).filter('#LoginForm').html();
            if (loginPage) {
                $('#img_Preloader').fadeOut('fast');
                $('#div_Fog').fadeOut('fast');
                $('#CenterBlockInner').html("<center>Critical error occured. Please go <a style='color:rgb(40, 134, 255); cursor:pointer; text-decoration:underline;' onclick='gotoPRIMA();'>back to PRIMA</a></center>");
                $('#CenterBlockInner').fadeIn('fast');
                return;
            }


                var EnrollmentChart_CountryId = $(html).filter('#div_CountryID').html();
                if (EnrollmentChart_CountryId > 0 || EnrollmentChart_CountryId == -1) {
                    $('.img_Chart').hide().html($(html).find('.img_Chart')).fadeIn('fast');
                    $('.Screened').html($(html).find('.Screened')).show('fast');
                    $('.Enrolled').html($(html).find('.Enrolled')).show('fast');
                    $('.Sites').html($(html).find('.Sites')).show('fast');
                    $('.btn-access2, .btn-noaccess2').attr('country', EnrollmentChart_CountryId).removeClass('btn-active');
                    $('.btn-access2').addClass('btn-active');

                    $('.Flag').removeClass('FlagActive');
                    $('.Flag[countryid="' + EnrollmentChart_CountryId + '"]').addClass('FlagActive');

                    $('.listRegions li').removeClass('CountryActive');
                    $('.listRegions li[countryid="' + EnrollmentChart_CountryId + '"]').addClass('CountryActive');
                } else {
                    if ($(html).filter('#div_NoData').length > 0 || $(html).find('#div_NoData').length > 0)
                        Show_NoDataWindow();
                    else {
                        $('#CenterBlockInner').html(html);
                        $('#CenterBlockInner').fadeIn('fast');
                    }
                }
                ScrollerInit();
                $('#img_Preloader').fadeOut('fast');
                $('#div_Fog').fadeOut('fast');
            }

            function Menu_DropDown_Click(actionName) {
                if (updateInProgress) return;

                switch (actionName) {
                    case 'DownLoad':
                        break;
                    //case 'EPMF':
                        //window.open('/EPMF30/psi_structure.aspx?project_id=' + project_id, '_blank');
                        //break;
                }
            }

            function gotoPRIMA() {
                document.location = '/pm/projects.aspx?query=' + $('#hfld_Query').val();
            }

            function ShowCountryFlags() {
                $('#FlagsPanel').fadeOut('fast');

            }
			
			$(document).on('click','.Flag, .listRegions li',function(){
				var id = $(this).attr('countryid');
				$('.Flag').removeClass('FlagActive');
				$('.Flag[countryid="'+id+'"]').addClass('FlagActive');
				
				$('img[countryid]').hide();
				$('img[countryid="'+id+'"]').fadeIn();
				
				$('#chart_div > div[countryid]').hide();
				$('#chart_div > div[countryid="'+id+'"]').fadeIn();
				
				if($('#chb_VALUES').length > 0){
				$('.btn-access2').removeClass('btn-active');
				$('#chb_VALUES').addClass('btn-active');
				}
				//alert($(this).attr('countryid'));
			})