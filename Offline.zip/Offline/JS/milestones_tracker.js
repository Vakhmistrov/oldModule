var errorMessage = null;
$(document).ready(function () {
    if (typeof String.prototype.trim !== 'function') {
        String.prototype.trim = function () {
            return this.replace(/^\s+|\s+$/g, '');
        }
    }

    Milestones_Calendars_Init();
});

var AdWidth = window.innerWidth;// <%= AdWidth %>;
var AdHeight = window.innerHeight;// <%= AdHeight %>;

var new_TRACKER_ACTUAL_DATE_FORMATTED, new_TRACKER_FORECAST_DATE_FORMATTED, new_TRACKER_COMMENTS;
var tmp_TRACKER_ACTUAL_DATE_FORMATTED, tmp_TRACKER_FORECAST_DATE_FORMATTED, tmp_TRACKER_COMMENTS;

function Milestones_Calendars_Init() {
    //if ($('#TRACKER_FORECAST_END_DATE_FORMATTED') && $('#img_CalendarButton1')) {
    if ($('#TRACKER_FORECAST_DATE_SUGGESTED_FORMATTED') && $('#img_CalendarButton1')) {
        Calendar.setup({
            //inputField: document.getElementById('TRACKER_FORECAST_END_DATE_FORMATTED').id,
            inputField: document.getElementById('TRACKER_FORECAST_DATE_SUGGESTED_FORMATTED').id,
            trigger: document.getElementById('img_CalendarButton1').id,
            onSelect: function () { this.hide(); ChangePosition(); },
            showTime: false,
            dateFormat: '%d-%b-%Y',
            align: 'Bl/ / /T/r'
        });
    }; 
    if ($('#TRACKER_ACTUAL_DATE_SUGGESTED_FORMATTED') && $('#img_CalendarButton2')) {
    	Calendar.setup({
    	    inputField: document.getElementById('TRACKER_ACTUAL_DATE_SUGGESTED_FORMATTED').id,
    		trigger    : document.getElementById('img_CalendarButton2').id,
    		onSelect: function () { this.hide(); ChangePosition(); },
    		showTime   : false,
    		dateFormat : '%d-%b-%Y',
    		align : 'Bl/ / /T/r'
    	});
    };

    var trVal = $('#TRACKER_FORECAST_DATE_SUGGESTED_FORMATTED');
    if (trVal) { trVal.change(function () { trVal.val(trVal.val().toUpperCase()) }); }
    //trVal = $('#TRACKER_FORECAST_DATE_FORMATTED');
    //if (trVal) { trVal.change(function () { trVal.val(trVal.val().toUpperCase()) } ); }
}

function ShowPopup(
	MILESTONE_NAME,
	TRACKER_UPDATED_BY,
	TRACKER_UPDATED_AT_FORMATTED,
	PLANNED_DATE_FORMATTED,
	TRACKER_ACTUAL_DATE_FORMATTED,
	TRACKER_FORECAST_DATE_FORMATTED,
	TRACKER_ACTUAL_DATE_SUGGESTED_FORMATTED,
	TRACKER_FORECAST_DATE_SUGGESTED_FORMATTED,
	TRACKER_COMMENTS,
	MILESTONE_ID,
	TRACKER_RECORD_ID,
	SG_visibility
	) {
    $('#Popup_Error').css('display', 'none');
    errorMessage = null;

    tmp_TRACKER_ACTUAL_DATE_FORMATTED = TRACKER_ACTUAL_DATE_FORMATTED;
    tmp_TRACKER_FORECAST_DATE_FORMATTED = TRACKER_FORECAST_DATE_FORMATTED;
    tmp_TRACKER_COMMENTS = TRACKER_COMMENTS;

    $('#div_Fog').css('display', '');
    $('#div_Popup').css({ display: '', top: (AdHeight / 2 - 250), left: (AdWidth / 2 - 250) });
    $('#div_Fog_Text').css({ top: (AdHeight / 2 - 50) });

    $('#Popup_Header').html(MILESTONE_NAME);

    if (TRACKER_UPDATED_BY != "-1") {
        $('#TRACKER_UPDATED_BY').html(TRACKER_UPDATED_BY);
        $('#TRACKER_UPDATED_AT_FORMATTED').html(TRACKER_UPDATED_AT_FORMATTED);
    }
    else
        $('#Record_History').html('&nbsp;');

    $('#PLANNED_DATE_FORMATTED').val(PLANNED_DATE_FORMATTED);
    $('#TRACKER_ACTUAL_DATE_FORMATTED').val(TRACKER_ACTUAL_DATE_FORMATTED);
    $('#TRACKER_FORECAST_DATE_FORMATTED').val(TRACKER_FORECAST_DATE_FORMATTED);

    CheckDate(document.getElementById('TRACKER_ACTUAL_DATE_FORMATTED'));
    CheckDate(document.getElementById('TRACKER_FORECAST_DATE_FORMATTED'));
    if (errorMessage != null) ShowError(errorMessage);

    if (SG_visibility == 'true') {
        $('#TRACKER_ACTUAL_DATE_SUGGESTED_FORMATTED').val(TRACKER_ACTUAL_DATE_SUGGESTED_FORMATTED);
        $('#TRACKER_FORECAST_DATE_SUGGESTED_FORMATTED').val(TRACKER_FORECAST_DATE_SUGGESTED_FORMATTED);
        $('#ph_SG1').css('display', '');
        $('#ph_SG2').css('display', '');
        $('#div_SuggestedLabel').css('display', '');
    }
    else {
        $('#ph_SG1').css('display', 'none');
        $('#ph_SG2').css('display', 'none');
        $('#div_SuggestedLabel').css('display', 'none');
    }

    $('#TRACKER_COMMENTS').val(TRACKER_COMMENTS);

    $('#hfld_MILESTONE_ID').val(MILESTONE_ID);
    $('#hfld_TRACKER_RECORD_ID').val(TRACKER_RECORD_ID);
}
function Hide_Popup() {
    $('#div_Fog').css('display', 'none');
    $('.div_Popup').css('display', 'none');
    Recalculate_All();
}

function Cancel_OnClick() {
    $('#div_Fog').css('display', 'none');
    $('.div_Popup').css('display', 'none');
}

function CopyValue(el_Target, el_Source) {
    el_Target.val(el_Source.val());
    el_Target.css('background-color', '#F9EAC5');
    el_Target.animate({ backgroundColor: 'white' }, 800);
}

function Send_n_Save() {
    if ($('#chk_Send').prop("checked"))
        __doPostBack('btn_Save', 'send');
    else
        __doPostBack('btn_Save', '');
}

function Check() {
    //if ($('#TRACKER_ACTUAL_DATE_FORMATTED').val().trim() == '') { ShowError('Actual date may not be empty'); return; }
    //if ($('#TRACKER_FORECAST_DATE_FORMATTED').val().trim() == '') { ShowError('Forecast date may not be empty'); return; }

    new_TRACKER_ACTUAL_DATE_FORMATTED = $('#TRACKER_ACTUAL_DATE_FORMATTED').val().trim();
    new_TRACKER_FORECAST_DATE_FORMATTED = $('#TRACKER_FORECAST_DATE_FORMATTED').val().trim();
    new_TRACKER_COMMENTS = $('#TRACKER_COMMENTS').val().trim();

    if (new_TRACKER_ACTUAL_DATE_FORMATTED == tmp_TRACKER_ACTUAL_DATE_FORMATTED
		&& new_TRACKER_FORECAST_DATE_FORMATTED == tmp_TRACKER_FORECAST_DATE_FORMATTED
		&& new_TRACKER_COMMENTS == tmp_TRACKER_COMMENTS) {
        Cancel_OnClick();
        return false;
    }

    var today = new Date();
    var d = new Date();

    d.setTime(Date.parse(new_TRACKER_ACTUAL_DATE_FORMATTED));
    if (d > today) { errorMessage = 'Actual date may not be in the future'; return false; }

    d.setTime(Date.parse(new_TRACKER_FORECAST_DATE_FORMATTED));
    if (new_TRACKER_ACTUAL_DATE_FORMATTED == '' && d < today) { errorMessage = 'Forecast date may not be in the past'; return false; }

    if (!CheckDate(document.getElementById('TRACKER_ACTUAL_DATE_FORMATTED'))) return false;
    if (!CheckDate(document.getElementById('TRACKER_FORECAST_DATE_FORMATTED'))) return false;

    $('#hfld_TRACKER_ACTUAL_DATE_FORMATTED').val(new_TRACKER_ACTUAL_DATE_FORMATTED);
    $('#hfld_TRACKER_FORECAST_DATE_FORMATTED').val(new_TRACKER_FORECAST_DATE_FORMATTED);
    $('#hfld_TRACKER_COMMENTS').val(new_TRACKER_COMMENTS);

    return true;
}

function Save() {
    if (Check()) {
        if (new_TRACKER_ACTUAL_DATE_FORMATTED != tmp_TRACKER_ACTUAL_DATE_FORMATTED && new_TRACKER_ACTUAL_DATE_FORMATTED != '')
            ShowPopupWarning();
        else
            __doPostBack('btn_Save', '');
    }
    else {
        if (errorMessage != null) ShowError(errorMessage);
    }
}

function ShowPopupWarning() {
    $('#div_Fog_for_Popup').css('display', '');
    $('#div_PopupWarning').css({ display: '', top: (AdHeight / 2 - 240), left: (AdWidth / 2 - 240) });
    $('#warnName').html($('#Popup_Header').html());
    $('#warnDate').html($('#TRACKER_ACTUAL_DATE_FORMATTED').val());
}

function CheckDate(e) {
    if (e.value.trim() == '') {
        //errorMessage = 'No data entered - ' + e.id;
        return true;
    }
    if (!Date.parse(e.value)) {
        e.style.backgroundColor = '#FFD5D5';
        errorMessage = 'Wrong date entered';
        return false;
    }
    else {
        var d = new Date(Date.parse(e.value));
        if (d < 1990) {
            e.style.backgroundColor = '#FFD5D5';
            errorMessage = 'Wrong date entered';
            return false;
        }
        else {
            e.style.backgroundColor = 'white';
            return true;
        }
    }
}

function ShowError(ErrorMesasge) {
    $('#Popup_Error').css('display', '');
    $('#Popup_Error').html(ErrorMesasge);
}
