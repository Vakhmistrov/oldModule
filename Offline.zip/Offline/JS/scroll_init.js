﻿function ScrollerInit() {
    //return;
    //var FilterPanel_Height = $('.CenterBlockInner').find('.filterPanel').outerHeight();
    //if (FilterPanel_Height > 0) { FilterPanel_Height += 20 }
    //$('#divForNiceScroller').height($('.CenterBlockInner').height() - FilterPanel_Height);
    //var gNiceScroll;
    //function AddNiceScrollbar() {
    //	if (gNiceScroll)
    //		gNiceScroll.Remove();
    //	gNiceScroll = new TR.NiceScroll("#divForNiceScroller_Inner");
    //	gNiceScroll.Add();
    //}
    //AddNiceScrollbar();

    var CenterBlockInner_width = parseInt($('#CenterBlockInner').outerWidth());

    function scrollGrid(tag) {
		alert(123);
        $(tag).css({ 'position': 'relative' });
        $(tag + ' thead, ' + tag + ' tbody, ' + tag + ' tfoot').css({ 'display': 'block' });

        var Sponsor_grid = ($('#table_Info').length > 0) ? $('#table_Info').outerHeight() + $('.sponsor_info_header').outerHeight() + 50 : 0;
        var Milestones_grid = ($('.labels').length > 0) ? $('.labels').outerHeight() + 15 : 0;

        $(tag + ' tbody').css("max-height", $('.CenterBlockInner').outerHeight() - 50 - Sponsor_grid - Milestones_grid - $(tag + ' thead').outerHeight() - $(tag + ' tfoot').outerHeight() + "px");

        var cols_width = 0;
        var first_col_width = 0;
        var auto_width_index = 0;

        //--start block-- this condition to get index of auto width column
        $(tag + ' tbody').find('tr').eq(0).find('td').filter(':visible').each(function (index, elem) {
            if ($(elem).hasClass('auto_width') || $(elem).find('.auto_width').length > 0) {
                auto_width_index = index;
            }
        });
        //--end block-- this condition to get index of auto width column

        $(tag + ' tbody').find('tr').eq(0).find('td').filter(':visible').each(function (index, elem) {
            if (index != auto_width_index) {
                cols_width += parseInt($(elem).outerWidth());
                //console.log(index + ' _ ' + parseInt($(elem).outerWidth()));
            }
        });

        first_col_width = CenterBlockInner_width - cols_width;
        //console.log(CenterBlockInner_width + ' - ' + cols_width);
        if (auto_width_index != 0) {   // 18.10.2016   AZ  this condition for column that has class='auto_width' (ItemStyle-CssClass="auto_width")
            $(tag + ' thead tr:first-child th').eq(auto_width_index).css('width', first_col_width + 'px');
            $(tag + ' tbody tr:first-child td').eq(auto_width_index).css('width', first_col_width + 'px');
            $(tag + ' tfoot tr:first-child td').eq(auto_width_index).css('width', first_col_width + 'px');
        } else {
            $(tag + ' thead tr:first-child th:first-child, ' + tag + ' tbody tr:first-child td:first-child, ' + tag + ' tfoot tr:first-child td:first-child').css('width', first_col_width + 'px');
        }

        //--start-block-- this width for element with css 'text-overflow: ellipsis' - used in invoices_log.aspx
        var ellipsis_element = $(tag + ' tbody tr td').filter(function () { return $(this).find('div').css('text-overflow') == 'ellipsis'; });
        $(ellipsis_element).find('div').width(first_col_width);


        $('.nicescroll-rails').remove();
        var tbody_height = $('.CenterBlockInner').outerHeight() - 50 - Sponsor_grid - Milestones_grid - $(tag + ' thead').outerHeight() - $(tag + ' tfoot').outerHeight();
        var cols_height = 0;
        $(tag + ' tbody tr').each(function () {
            cols_height += parseInt($(this).outerHeight());
        });

        if (tbody_height < cols_height) {
            $(tag + ' .nicescroll-rails').remove();
            $(tag + ' tbody').niceScroll({
                cursorcolor: "#beced4",
                cursoropacitymin: 0.9,
                background: "#FFFFFF",
                cursorborder: "0",
                cursorwidth: "8px",
                cursorminheight: 30,
                autohidemode: true,
                zindex: 35
            });

            TableArrows(tag, cols_height);
        }
    }

    function TableArrows(object, dg_MasterList_height) {
        var obj = $(object);

        obj.css('position', 'relative');
        var BlockScroll = obj.find('tbody');

        BlockScroll.before($('<div>').attr('class', 'TopScroll').html('<span></span>'));
        BlockScroll.after($('<div>').attr('class', 'BottomScroll').html('<span></span>'));

        UIgrid_thead_height = obj.find('thead').outerHeight();
        UIGrid_tfoot_height = obj.find('tfoot').outerHeight();

        var TopScroll = obj.find('.TopScroll');
        var BottomScroll = obj.find('.BottomScroll');

        TopScroll.css('top', UIgrid_thead_height + 'px');
        BottomScroll.css('bottom', UIGrid_tfoot_height + 'px');

        var scrollBottom = $(object).scrollTop() + $(object).outerHeight();
        if (BlockScroll.height() < dg_MasterList_height) { BottomScroll.fadeIn('fast'); }

        BlockScroll.scroll(function () {
            if ($(this).scrollTop() > 5) {
                TopScroll.fadeIn('fast');
            } else { TopScroll.fadeOut('fast'); }
            scrollBottom = $(this).scrollTop() + $(this).outerHeight();
            if (scrollBottom >= dg_MasterList_height) {
                BottomScroll.fadeOut('fast');
            } else { BottomScroll.fadeIn('fast'); }
        });

        TopScroll.click(function () {
            var ScrollStep = 80;
            BlockScroll.animate({ scrollTop: BlockScroll.scrollTop() - ScrollStep }, 300);
            $('.tr_scrollbar_inner').animate({ top: ScrollStep }, 300);
        });

        BottomScroll.click(function () {
            var ScrollStep = 80;
            BlockScroll.animate({ scrollTop: BlockScroll.scrollTop() + ScrollStep }, 300);
            $('.tr_scrollbar_inner').animate({ top: ScrollStep }, 300);
        });
    }

    if ($('#dg_MasterList').length > 0) {

        scrollGrid('#dg_MasterList');

    } else if ($('#dg_FilesList').length > 0) { //dg_FileList
        $('#dg_FilesList').css({ 'position': 'relative' });
        $('#dg_FilesList thead, #dg_FilesList tbody, #dg_FilesList tfoot').css({ 'display': 'block' });

        var UIGrid_tbody_height = $('.CenterBlockInner').outerHeight() - 50 - $('#dg_FilesList thead').outerHeight() - $('#dg_FilesList tfoot').outerHeight();
        if ($('#dg_FilesList tfoot').length > 0) {
            $('#dg_FilesList tbody').css("max-height", UIGrid_tbody_height + "px");
        } else {
            $('#dg_FilesList tbody').css("height", UIGrid_tbody_height + "px");
        }


        var dg_FilesList_cols_width = 0;
        var dg_FilesList_first_col_width = 0;

        $('#dg_FilesList tbody').find('tr').eq(0).find('td').each(function (index, elem) {
            if (index > 0) {
                //console.log($(elem).outerWidth());
                dg_FilesList_cols_width += parseInt($(elem).outerWidth());
            }
        })

        dg_FilesList_first_col_width = CenterBlockInner_width - dg_FilesList_cols_width;
        //console.log(dg_FilesList_first_col_width);
        $('#dg_FilesList thead tr:first-child th:first-child, #dg_FilesList tbody tr:first-child td:first-child, #dg_FilesList tfoot tr:first-child td:first-child').css('width', dg_FilesList_first_col_width + 'px');

        $(".ProgressSince tbody, #dg_FilesList tbody").niceScroll({
            cursorcolor: "#beced4",
            cursoropacitymin: 0.9,
            //background: "#FFFFFF",
            cursorborder: "0",
            cursorwidth: "8px",
            cursorminheight: 30
        });

        var dg_FilesList_BlockScroll = $('#dg_FilesList tbody');
        var dg_FilesList_ContentScroll = $('#dg_FilesList tbody');

        var dg_FilesList_tbody_height = 0;

        dg_FilesList_ContentScroll.find('tr').each(function (index, elem) {
            if (index > 0) {
                dg_FilesList_tbody_height += parseInt($(elem).outerHeight());
            }
        })

        dg_FilesList_BlockScroll.before($('<div>').attr('class', 'TopScroll').html('<span></span>'));
        dg_FilesList_BlockScroll.after($('<div>').attr('class', 'BottomScroll').html('<span></span>'));

        dg_FilesList_thead_height = $('#dg_FilesList thead').outerHeight();
        dg_FilesList_tfoot_height = $('#dg_FilesList tfoot').outerHeight();

        var dg_FilesList_TopScroll = $('.TopScroll');
        var dg_FilesList_BottomScroll = $('.BottomScroll');

        dg_FilesList_TopScroll.css('top', dg_FilesList_thead_height + 'px');
        dg_FilesList_BottomScroll.css('bottom', dg_FilesList_tfoot_height + 'px');

        var dg_FilesList_scrollBottom = $(this).scrollTop() + $(this).height();
        //var realHeight = dg_FilesList_ContentScroll.height();
        var dg_FilesList_realHeight = dg_FilesList_tbody_height + 30;

        if (dg_FilesList_BlockScroll.height() < dg_FilesList_realHeight) { dg_FilesList_BottomScroll.fadeIn('fast'); }

        dg_FilesList_BlockScroll.scroll(function () {
            if ($(this).scrollTop() > 5) {
                dg_FilesList_TopScroll.fadeIn('fast');
            } else { dg_FilesList_TopScroll.fadeOut('fast'); }
            dg_FilesList_scrollBottom = $(this).scrollTop() + $(this).height();
            //realHeight = dg_FilesList_ContentScroll.height();
            dg_FilesList_realHeight = dg_FilesList_tbody_height;
            if (dg_FilesList_scrollBottom >= dg_FilesList_realHeight + 10) {
                dg_FilesList_BottomScroll.fadeOut('fast');
            } else { dg_FilesList_BottomScroll.fadeIn('fast'); }
        });

        dg_FilesList_TopScroll.click(function () {
            var ScrollStep = 80;
            var tr_scrollbar_inner_Top = $('.tr_scrollbar_inner').position();
            dg_FilesList_BlockScroll.animate({ scrollTop: dg_FilesList_BlockScroll.scrollTop() - ScrollStep }, 300);
            $('.tr_scrollbar_inner').animate({ top: tr_scrollbar_inner_Top.top - ScrollStep }, 300);
        });

        dg_FilesList_BottomScroll.click(function () {
            var ScrollStep = 80;
            var tr_scrollbar_inner_Top = $('.tr_scrollbar_inner').position();
            dg_FilesList_BlockScroll.animate({ scrollTop: dg_FilesList_BlockScroll.scrollTop() + ScrollStep }, 300);
            $('.tr_scrollbar_inner').animate({ top: tr_scrollbar_inner_Top.top + ScrollStep }, 300);
        });


    }

    else if ($('#dg_DeviationsList').length > 0) {
    scrollGrid('#dg_DeviationsList');
    }

    else if ($('#dg_SAEsList').length > 0) {
        scrollGrid('#dg_SAEsList');
    }
    else if ($('#dg_IssuesList').length > 0) {
        scrollGrid('#dg_IssuesList');
    }

    //$('#divForNiceScroller').css('visibility', 'visible');
}