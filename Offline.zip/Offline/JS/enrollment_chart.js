﻿
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}

function FlagNavigation(){
    $('#dock2').Fisheye(
    {
        maxWidth: 60,
        items: '.dock-item2',
        itemsText: 'span',
        container: '.dock-container2',
        itemWidth: 40,
        proximity: 80,
        alignment: 'center',
        valign: 'bottom',
        halign: 'center'
    }
    )
}

function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>

//$('#div_Fog').hide(); // added AV

$('.btn-access2, .btn-noaccess2').click(function () {
    country_id = $(this).attr('country');
    view_mode = $(this).attr('mode');
    //LoadPage_Ajax('Enrollment_Chart', this, { action: 'ChangeMode', CountryID: country_id, VIEW_MODE: view_mode });
    $.post('/PPT/Modules/enrollment_chart.aspx', {
        CountryID: country_id,
        VIEW_MODE: view_mode,
        em_id: '174',
        width: ($('#CenterBlockInner').width() - 325),
        height: ($('#CenterBlockInner').outerHeight() - 40)
    }, function (html) { NewData = $(html).find('.img_Chart'); $('.img_Chart').hide().html(NewData).fadeIn('fast'); });
    $('.btn-access2, .btn-noaccess2').removeClass('btn-active');
    $(this).addClass('btn-active');
});


$(document).on('click', '.NavFlag, .AllRegions', function () {
    $('.NavFlag,.AllRegions').removeClass('Active');
    if (this != 'AllRegions') { $(this).addClass('Active'); }
});


$('.view_more').click(function () {
    $(this).fadeOut('fast');
    $('.Pie_Chart').fadeOut('fast', function () { $('.table_Screenout').animate({ height: 110 }, 'fast'); });
    $('.hide_more').delay(800).fadeIn('fast');
    return;
})


$(document).on('click', '.hide_more', function () {


    $(this).fadeOut('fast', function () { $('.table_Screenout').animate({ height: 25 }, 'fast'); $('.Pie_Chart').delay(300).fadeIn(); $('.view_more').delay(290).fadeIn(); });
})


if ($(window).height() < 1000) {
    $('.table_Screenout').height(25);
    $('.view_more').show();
}