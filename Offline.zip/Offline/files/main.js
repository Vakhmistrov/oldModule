﻿toastr.options = {
        tapToDismiss: true,
        toastClass: 'toast',
        containerId: 'toast-container',
        debug: false,

        //showMethod: 'fadeIn', //fadeIn, slideDown, and show are built into jQuery
        showEasing: 'swing', //swing and linear are built into jQuery
        onShown: undefined,
        //hideMethod: 'fadeOut',
        hideDuration: 1000,
        hideEasing: 'swing', // swing or none (for always show popup
        onHidden: undefined,
        closeMethod: false,
        closeDuration: false,
        closeEasing: false,
        closeOnHover: true,
        timeOut: 5000,
        extendedTimeOut: 1000,
        iconClasses: {
            error: 'prima-toast-error',
            info: 'toast-info',
            success: 'toast-success',
            warning: 'toast-warning'
        },
        iconClass: 'toast-info',
        positionClass: 'toast-top-right',
        titleClass: 'Prima-toast-title',
        messageClass: 'Prima-toast-message',
        escapeHtml: false,
        target: 'body',
        closeHtml: '<button type="button">&times;</button>',
        closeClass: 'toast-close-button',
        newestOnTop: true,
        preventDuplicates: false,
        progressBar: false,
        progressClass: 'toast-progress',
        rtl: false
    };